/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-6.1.0/configure --prefix=/opt/gcc/6.1.0 --enable-languages=c,c++,fortran";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "core2" } };
